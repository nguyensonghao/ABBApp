const APP_NAME = "ABBapp";
const COUNT_DOWN_TIME = "October 18, 2017 00:00:00"