const FIREBASE_CONFIG = {
    apiKey: "AIzaSyACZrquGOI4HS89PBC3GEd2VHQW6eMxYWA",
    authDomain: "abbapp-b24de.firebaseapp.com",
    databaseURL: "https://abbapp-b24de.firebaseio.com",
    projectId: "abbapp-b24de",
    storageBucket: "abbapp-b24de.appspot.com",
    messagingSenderId: "970186246171"
};